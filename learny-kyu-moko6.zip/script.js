document.addEventListener('DOMContentLoaded', () => {
  const year = document.getElementById('year');
  if (year) {
    year.textContent = new Date().getFullYear();
  }

  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.main-nav');
  const navActions = document.querySelector('.nav-actions');

  if (toggle && nav && navActions) {
    toggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      navActions.classList.toggle('open', isOpen);
      toggle.setAttribute('aria-expanded', String(isOpen));
    });
  }

  const enrollButtons = document.querySelectorAll('.course-enroll');
  const enrolledClasses = document.getElementById('enrolled-classes');
  const classesEmpty = document.getElementById('classes-empty');
  const classesStatus = document.getElementById('classes-status');
  const noteForm = document.getElementById('note-form');
  const noteTitle = document.getElementById('note-title');
  const noteClass = document.getElementById('note-class');
  const noteContent = document.getElementById('note-content');
  const noteStatus = document.getElementById('note-status');
  const notesEmpty = document.getElementById('notes-empty');
  const notesList = document.getElementById('notes-list');

  if (
    !enrollButtons.length ||
    !enrolledClasses ||
    !classesEmpty ||
    !classesStatus ||
    !noteForm ||
    !noteTitle ||
    !noteClass ||
    !noteContent ||
    !noteStatus ||
    !notesEmpty ||
    !notesList
  ) {
    return;
  }

  const courseCards = [...document.querySelectorAll('.course-card[data-course-id]')];
  const courses = new Map(
    courseCards.map((card) => [
      card.dataset.courseId,
      {
        id: card.dataset.courseId,
        title: card.querySelector('h3')?.textContent.trim() || '',
        category: card.querySelector('.course-tag')?.textContent.trim() || 'Class',
        duration: card.querySelector('.course-meta span')?.textContent.trim() || '',
      },
    ])
  );
  let enrolledIds = new Set();
  let notes = [];

  const apiRequest = async (endpoint, options = {}) => {
    const response = await fetch(endpoint, {
      ...options,
      headers: {
        ...(options.body ? { 'Content-Type': 'application/json' } : {}),
        ...options.headers,
      },
    });
    if (!response.ok) {
      const result = await response.json().catch(() => ({}));
      throw new Error(result.error || `Request failed (${response.status}).`);
    }
    return response.status === 204 ? null : response.json();
  };

  const renderEnrolledClasses = () => {
    enrolledClasses.replaceChildren();
    classesEmpty.hidden = enrolledIds.size > 0;

    enrolledIds.forEach((id) => {
      const course = courses.get(id);
      if (!course) return;

      const card = document.createElement('article');
      card.className = 'enrolled-card';

      const category = document.createElement('span');
      category.className = 'enrolled-category';
      category.textContent = course.category;

      const title = document.createElement('h3');
      title.textContent = course.title;

      const duration = document.createElement('p');
      duration.textContent = course.duration;

      const notesButton = document.createElement('button');
      notesButton.className = 'btn btn-secondary';
      notesButton.type = 'button';
      notesButton.textContent = 'Take notes';
      notesButton.addEventListener('click', () => {
        noteClass.value = course.id;
        document.getElementById('notes').scrollIntoView({ behavior: 'smooth' });
        noteTitle.focus({ preventScroll: true });
      });

      card.append(category, title, duration, notesButton);
      enrolledClasses.append(card);
    });

    Array.from(noteClass.options)
      .filter((option) => option.value)
      .forEach((option) => option.remove());

    enrolledIds.forEach((id) => {
      const course = courses.get(id);
      if (!course) return;

      const option = document.createElement('option');
      option.value = course.id;
      option.textContent = course.title;
      noteClass.append(option);
    });
  };

  const updateEnrollmentButtons = () => {
    enrollButtons.forEach((button) => {
      const isEnrolled = enrolledIds.has(button.dataset.courseId);
      button.disabled = isEnrolled;
      button.textContent = isEnrolled ? 'Enrolled' : 'Enroll in class';
    });
  };

  enrollButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const id = button.dataset.courseId;
      if (!id || !courses.has(id) || enrolledIds.has(id)) return;

      button.disabled = true;
      classesStatus.textContent = '';
      apiRequest('/api/enrollments', {
        method: 'POST',
        body: JSON.stringify({ courseId: id }),
      })
        .then(() => apiRequest('/api/enrollments'))
        .then((enrollments) => {
          enrolledIds = new Set(enrollments.map((item) => item.courseId));
          updateEnrollmentButtons();
          renderEnrolledClasses();
          noteClass.value = id;
        })
        .catch((error) => {
          button.disabled = false;
          classesStatus.textContent = error.message;
        });
    });
  });

  const renderNotes = () => {
    notesList.replaceChildren();
    notesEmpty.hidden = notes.length > 0;

    notes.forEach((note) => {
      const card = document.createElement('article');
      card.className = 'note-card';

      const header = document.createElement('div');
      header.className = 'note-card-header';

      const title = document.createElement('h4');
      title.textContent = note.title;

      const removeButton = document.createElement('button');
      removeButton.className = 'note-delete';
      removeButton.type = 'button';
      removeButton.textContent = 'Delete';
      removeButton.setAttribute('aria-label', `Delete note: ${note.title}`);
      removeButton.addEventListener('click', async () => {
        removeButton.disabled = true;
        try {
          await apiRequest(`/api/notes/${encodeURIComponent(note.id)}`, { method: 'DELETE' });
          notes = notes.filter((item) => item.id !== note.id);
          renderNotes();
          noteStatus.textContent = '';
        } catch (error) {
          removeButton.disabled = false;
          noteStatus.textContent = error.message;
        }
      });

      const category = document.createElement('span');
      category.className = 'note-category';
      category.textContent = note.classId
        ? courses.get(note.classId)?.title || 'Class note'
        : 'Personal note';

      const content = document.createElement('p');
      content.textContent = note.content;

      header.append(title, removeButton);
      card.append(category, header, content);
      notesList.append(card);
    });
  };

  noteForm.addEventListener('submit', async (event) => {
    event.preventDefault();

    const title = noteTitle.value.trim();
    const content = noteContent.value.trim();
    noteStatus.textContent = '';
    if (!title || !content) {
      noteStatus.textContent = 'Please add a title and note before saving.';
      return;
    }

    const submitButton = noteForm.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    try {
      const note = await apiRequest('/api/notes', {
        method: 'POST',
        body: JSON.stringify({ title, content, classId: noteClass.value }),
      });
      notes.unshift(note);
      noteForm.reset();
      noteStatus.textContent = 'Your note was added.';
      renderNotes();
    } catch (error) {
      noteStatus.textContent = error.message;
    } finally {
      submitButton.disabled = false;
    }
  });

  Promise.all([apiRequest('/api/enrollments'), apiRequest('/api/notes')])
    .then(([enrollments, savedNotes]) => {
      enrolledIds = new Set(enrollments.map((item) => item.courseId));
      notes = savedNotes;
      updateEnrollmentButtons();
      renderEnrolledClasses();
      renderNotes();
    })
    .catch((error) => {
      classesStatus.textContent = `Could not load your classes: ${error.message}`;
      noteStatus.textContent = `Could not load your notes: ${error.message}`;
    });
});
