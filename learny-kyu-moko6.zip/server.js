const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');

const PORT = Number(process.env.PORT) || 3000;
const ROOT = __dirname;
const MAX_BODY_BYTES = 16 * 1024;
const courses = [
  { id: 'ux-design', title: 'UX Design Foundations', category: 'Design', duration: '6 weeks' },
  { id: 'frontend', title: 'Frontend Launchpad', category: 'Development', duration: '8 weeks' },
  { id: 'growth-marketing', title: 'Growth Marketing Lab', category: 'Marketing', duration: '4 weeks' },
];

function loadStore(dataFile) {
  try {
    const data = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
    if (!Array.isArray(data.enrollments) || !Array.isArray(data.notes)) {
      throw new Error('The data file must contain enrollments and notes arrays.');
    }
    return data;
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    fs.mkdirSync(path.dirname(dataFile), { recursive: true });
    const initialData = { enrollments: [], notes: [] };
    fs.writeFileSync(dataFile, JSON.stringify(initialData, null, 2));
    return initialData;
  }
}

function sendJson(response, statusCode, data) {
  response.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  response.end(data === undefined ? '' : JSON.stringify(data));
}

function readJsonBody(request) {
  return new Promise((resolve, reject) => {
    let body = '';
    let tooLarge = false;

    request.setEncoding('utf8');
    request.on('data', (chunk) => {
      if (tooLarge) return;
      body += chunk;
      if (Buffer.byteLength(body, 'utf8') > MAX_BODY_BYTES) {
        tooLarge = true;
        reject(Object.assign(new Error('Request body is too large.'), { statusCode: 413 }));
      }
    });
    request.on('end', () => {
      if (tooLarge) return;
      try {
        resolve(JSON.parse(body));
      } catch {
        reject(Object.assign(new Error('Request body must be valid JSON.'), { statusCode: 400 }));
      }
    });
    request.on('error', reject);
  });
}

function createServer({ dataFile = path.join(ROOT, 'data', 'store.json') } = {}) {
  let store = loadStore(dataFile);
  let writeQueue = Promise.resolve();

  function updateStore(updater) {
    const operation = writeQueue.then(async () => {
      const next = JSON.parse(JSON.stringify(store));
      const result = updater(next);
      const temporaryFile = `${dataFile}.${process.pid}.${randomUUID()}.tmp`;
      await fs.promises.mkdir(path.dirname(dataFile), { recursive: true });
      await fs.promises.writeFile(temporaryFile, JSON.stringify(next, null, 2));
      await fs.promises.rename(temporaryFile, dataFile);
      store = next;
      return result;
    });
    writeQueue = operation.catch(() => {});
    return operation;
  }

  return http.createServer(async (request, response) => {
    let pathname;
    try {
      pathname = new URL(request.url, 'http://localhost').pathname;
    } catch {
      sendJson(response, 400, { error: 'Invalid request URL.' });
      return;
    }

    try {
      if (request.method === 'GET' && pathname === '/api/courses') {
        sendJson(response, 200, courses);
        return;
      }

      if (request.method === 'GET' && pathname === '/api/enrollments') {
        sendJson(response, 200, store.enrollments);
        return;
      }

      if (request.method === 'POST' && pathname === '/api/enrollments') {
        const body = await readJsonBody(request);
        if (typeof body.courseId !== 'string' || !courses.some((course) => course.id === body.courseId)) {
          sendJson(response, 400, { error: 'Choose a valid class to enroll in.' });
          return;
        }
        const enrollment = await updateStore((next) => {
          if (next.enrollments.some((item) => item.courseId === body.courseId)) {
            throw Object.assign(new Error('You are already enrolled in this class.'), { statusCode: 409 });
          }
          const item = { courseId: body.courseId, enrolledAt: new Date().toISOString() };
          next.enrollments.push(item);
          return item;
        });
        sendJson(response, 201, enrollment);
        return;
      }

      if (request.method === 'GET' && pathname === '/api/notes') {
        sendJson(response, 200, store.notes);
        return;
      }

      if (request.method === 'POST' && pathname === '/api/notes') {
        const body = await readJsonBody(request);
        const title = typeof body.title === 'string' ? body.title.trim() : '';
        const content = typeof body.content === 'string' ? body.content.trim() : '';
        const classId = typeof body.classId === 'string' ? body.classId : '';
        if (!title || title.length > 100 || !content || content.length > 2000) {
          sendJson(response, 400, { error: 'Add a title (up to 100 characters) and note (up to 2,000 characters).' });
          return;
        }
        if (classId && !courses.some((course) => course.id === classId)) {
          sendJson(response, 400, { error: 'Choose a valid class for this note.' });
          return;
        }
        if (classId && !store.enrollments.some((item) => item.courseId === classId)) {
          sendJson(response, 400, { error: 'Enroll in the class before saving a class note.' });
          return;
        }

        const note = await updateStore((next) => {
          const item = { id: randomUUID(), title, content, classId, createdAt: new Date().toISOString() };
          next.notes.unshift(item);
          return item;
        });
        sendJson(response, 201, note);
        return;
      }

      const noteMatch = pathname.match(/^\/api\/notes\/([^/]+)$/);
      if (request.method === 'DELETE' && noteMatch) {
        const noteId = decodeURIComponent(noteMatch[1]);
        const deleted = await updateStore((next) => {
          const index = next.notes.findIndex((note) => note.id === noteId);
          if (index === -1) return false;
          next.notes.splice(index, 1);
          return true;
        });
        if (!deleted) {
          sendJson(response, 404, { error: 'Note not found.' });
          return;
        }
        sendJson(response, 204);
        return;
      }

      if (request.method === 'GET') {
        const publicFiles = {
          '/': ['index.html', 'text/html; charset=utf-8'],
          '/index.html': ['index.html', 'text/html; charset=utf-8'],
          '/script.js': ['script.js', 'text/javascript; charset=utf-8'],
          '/style.css': ['style.css', 'text/css; charset=utf-8'],
        };
        const file = publicFiles[pathname];
        if (file) {
          const contents = await fs.promises.readFile(path.join(ROOT, file[0]));
          response.writeHead(200, { 'Content-Type': file[1] });
          response.end(contents);
          return;
        }
      }

      sendJson(response, 404, { error: 'Not found.' });
    } catch (error) {
      if (error.statusCode) {
        sendJson(response, error.statusCode, { error: error.message });
        return;
      }
      console.error('Request failed:', error);
      sendJson(response, 500, { error: 'The request could not be completed.' });
    }
  });
}

if (require.main === module) {
  const server = createServer();
  server.listen(PORT, () => {
    console.log(`Learnly server listening at http://localhost:${PORT}`);
  });
}

module.exports = { createServer };
