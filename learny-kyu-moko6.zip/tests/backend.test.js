const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { after, before, test } = require('node:test');
const { createServer } = require('../server');

let server;
let baseUrl;
let temporaryDirectory;

before(async () => {
  temporaryDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'learnly-test-'));
  server = createServer({ dataFile: path.join(temporaryDirectory, 'store.json') });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  await new Promise((resolve, reject) => {
    server.close((error) => (error ? reject(error) : resolve()));
  });
  fs.rmSync(temporaryDirectory, { recursive: true, force: true });
});

async function request(endpoint, options) {
  return fetch(`${baseUrl}${endpoint}`, options);
}

test('serves the site and course catalog', async () => {
  const page = await request('/');
  assert.equal(page.status, 200);
  assert.match(await page.text(), /Learnly/);

  const response = await request('/api/courses');
  assert.equal(response.status, 200);
  assert.equal((await response.json()).length, 3);
});

test('persists valid enrollments and rejects duplicates and unknown courses', async () => {
  const options = {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ courseId: 'frontend' }),
  };
  assert.equal((await request('/api/enrollments', options)).status, 201);
  assert.equal((await request('/api/enrollments', options)).status, 409);

  const invalid = await request('/api/enrollments', {
    ...options,
    body: JSON.stringify({ courseId: 'unknown' }),
  });
  assert.equal(invalid.status, 400);

  const response = await request('/api/enrollments');
  assert.deepEqual((await response.json()).map((item) => item.courseId), ['frontend']);
});

test('creates and deletes notes with validation', async () => {
  const options = {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title: '  Study plan  ', content: '  Review the basics  ', classId: '' }),
  };
  const created = await request('/api/notes', options);
  assert.equal(created.status, 201);
  const note = await created.json();
  assert.equal(note.title, 'Study plan');
  assert.equal(note.content, 'Review the basics');

  const invalidClassNote = await request('/api/notes', {
    ...options,
    body: JSON.stringify({ title: 'Class note', content: 'Not enrolled', classId: 'ux-design' }),
  });
  assert.equal(invalidClassNote.status, 400);

  assert.equal((await request(`/api/notes/${note.id}`, { method: 'DELETE' })).status, 204);
  assert.equal((await request(`/api/notes/${note.id}`, { method: 'DELETE' })).status, 404);
  assert.deepEqual(await (await request('/api/notes')).json(), []);
});
